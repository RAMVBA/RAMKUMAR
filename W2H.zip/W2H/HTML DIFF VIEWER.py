import difflib
from bs4 import BeautifulSoup

def clean_html(path):
    with open(path, encoding="utf-8") as f:
        soup = BeautifulSoup(f, "html.parser")

    for tag in soup(["script", "style", "img"]):
        tag.decompose()

    return soup.get_text("\n").splitlines()

def generate_diff(html1, html2, output):
    t1 = clean_html(html1)
    t2 = clean_html(html2)

    diff = difflib.HtmlDiff(tabsize=4, wrapcolumn=80)
    result = diff.make_file(
        t1, t2,
        fromdesc="Previous HTML",
        todesc="Current HTML"
    )

    with open(output, "w", encoding="utf-8") as f:
        f.write(result)

    print("HTML diff created:", output)


# ----------------------------
# RUN
# ----------------------------
if __name__ == "__main__":
    generate_diff(
        "old_version.htm",
        "new_version.htm",
        "HTML_Diff_Report.html"
    )
