import tkinter as tk
from tkinter import filedialog, messagebox
import subprocess

def run_pipeline():
    word = filedialog.askdirectory(title="Word Input")
    pdf = filedialog.askdirectory(title="PDF Input")
    out = filedialog.askdirectory(title="Output Folder")

    if not word or not out:
        return

    subprocess.run(["python", "word_to_edgar_enterprise.py", word, out])
    subprocess.run(["python", "sec_preflight.py"])
    subprocess.run(["python", "pdf_html_reconcile.py"])
    subprocess.run(["python", "xbrl_html_check.py"])

    messagebox.showinfo("SUCCESS", "EDGAR package ready")

root = tk.Tk()
root.title("EDGAR Filing Automation")
root.geometry("500x200")

tk.Button(
    root,
    text="RUN FULL EDGAR PIPELINE",
    font=("Arial", 14),
    width=30,
    command=run_pipeline
).pack(pady=60)

root.mainloop()
