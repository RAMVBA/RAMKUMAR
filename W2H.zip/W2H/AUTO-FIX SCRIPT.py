from bs4 import BeautifulSoup

def autofix_html(input_html, output_html):
    with open(input_html, encoding="utf-8") as f:
        soup = BeautifulSoup(f, "html.parser")

    # Ensure HTML/BODY
    if not soup.html:
        html = soup.new_tag("html")
        html.append(soup)
        soup = BeautifulSoup(str(html), "html.parser")

    if not soup.body:
        body = soup.new_tag("body")
        body.extend(soup.html.contents)
        soup.html.clear()
        soup.html.append(body)

    # Fix empty paragraphs
    for p in soup.find_all("p"):
        if not p.text.strip():
            p.string = "\u00a0"

    # Fix images (ALT required by Nova)
    for img in soup.find_all("img"):
        if not img.get("alt"):
            img["alt"] = ""

    # Collapse nested FONT tags
    for font in soup.find_all("font"):
        parent = font.parent
        if parent.name == "font":
            font.unwrap()

    with open(output_html, "w", encoding="utf-8") as f:
        f.write(str(soup))

    print("✔ Nova auto-fix applied:", output_html)


if __name__ == "__main__":
    autofix_html("input.htm", "fixed.htm")
