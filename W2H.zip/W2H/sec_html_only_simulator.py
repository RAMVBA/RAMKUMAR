import os
import re
import sys

FORBIDDEN_TAGS = [
    "<script",
    "<style",
    "<link",
    "<iframe",
    "<object"
]

IMAGE_RE = re.compile(r'<img[^>]+src="([^"]+)"', re.IGNORECASE)
PAGE_RE = re.compile(r'field:\s*page;\s*sequence:(\d+)', re.IGNORECASE)

def validate_html_file(path, base_dir):
    errors = []
    warnings = []

    with open(path, encoding="utf-8", errors="ignore") as f:
        html = f.read()

    lower = html.lower()

    # HTML / BODY
    if "<html" not in lower or "<body" not in lower:
        errors.append(f"{os.path.basename(path)}: Missing <HTML>/<BODY>")

    # Forbidden tags
    for tag in FORBIDDEN_TAGS:
        if tag in lower:
            errors.append(f"{os.path.basename(path)}: Forbidden tag {tag}")

    # Page fields
    pages = PAGE_RE.findall(html)
    if pages:
        expected = list(map(str, range(1, len(pages) + 1)))
        if pages != expected:
            errors.append(f"{os.path.basename(path)}: Page sequence broken")

    # Images
    for img in IMAGE_RE.findall(html):
        img_path = os.path.join(base_dir, img)
        if not os.path.exists(img_path):
            errors.append(f"{os.path.basename(path)}: Missing image {img}")

        if not re.match(r".+x\d+x\d+\.(jpg|png|gif)", img.lower()):
            warnings.append(f"{os.path.basename(path)}: Image naming not EDGAR-style ({img})")

    return errors, warnings


def simulate_html_only_submission(submission_dir):
    errors = []
    warnings = []

    html_files = [
        f for f in os.listdir(submission_dir)
        if f.lower().endswith((".htm", ".html"))
    ]

    if not html_files:
        errors.append("No HTML filing found")
        return errors, warnings

    for h in html_files:
        e, w = validate_html_file(
            os.path.join(submission_dir, h),
            submission_dir
        )
        errors.extend(e)
        warnings.extend(w)

    return errors, warnings


# -------------------------------
# RUN
# -------------------------------
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python sec_html_only_simulator.py <Submission_Folder>")
        sys.exit(1)

    submission = sys.argv[1]

    errs, warns = simulate_html_only_submission(submission)

    if errs:
        print("❌ HTML-ONLY SEC SIMULATION FAILED")
        for e in errs:
            print("ERROR:", e)
        sys.exit(1)
    else:
        print("✅ HTML-ONLY SEC SIMULATION PASSED")

    if warns:
        print("\n⚠ WARNINGS")
        for w in warns:
            print("WARNING:", w)
