import tkinter as tk
from tkinter import filedialog, messagebox
import subprocess
import sys
import os

def run_pipeline():
    word_dir = filedialog.askdirectory(title="Select Word Input Folder")
    if not word_dir:
        return

    output_dir = filedialog.askdirectory(title="Select Output Folder")
    if not output_dir:
        return

    use_xbrl = xbrl_var.get()

    try:
        # Word → EDGAR HTML
        subprocess.run(
            [sys.executable, "word_to_edgar_enterprise.py", word_dir, output_dir],
            check=True
        )

        # Nova auto-fix
        subprocess.run(
            [sys.executable, "autofix_html.py", output_dir],
            check=True
        )

        # SEC Simulation
        if use_xbrl:
            subprocess.run(
                [sys.executable, "sec_xbrl_simulator.py", output_dir],
                check=True
            )
        else:
            subprocess.run(
                [sys.executable, "sec_html_only_simulator.py", output_dir],
                check=True
            )

        messagebox.showinfo(
            "SUCCESS",
            "EDGAR validation PASSED.\nReady for submission."
        )

    except subprocess.CalledProcessError:
        messagebox.showerror(
            "FAILED",
            "Validation FAILED.\nCheck console output."
        )

# ---------------- GUI ----------------

root = tk.Tk()
root.title("EDGAR Filing Automation")
root.geometry("560x280")

xbrl_var = tk.BooleanVar(value=False)

tk.Label(
    root,
    text="EDGAR Filing Automation Tool",
    font=("Arial", 16, "bold")
).pack(pady=15)

tk.Checkbutton(
    root,
    text="XBRL Filing (10-K / 10-Q / S-1)",
    variable=xbrl_var,
    font=("Arial", 12)
).pack(pady=10)

tk.Button(
    root,
    text="RUN EDGAR VALIDATION",
    font=("Arial", 13),
    width=32,
    command=run_pipeline
).pack(pady=30)

root.mainloop()
