import re
import csv

ERROR_RE = re.compile(
    r"(ERROR|WARNING):\s+Page\s+(\d+)\s+-\s+(.*)",
    re.IGNORECASE
)

def parse_nova_report(report_path, output_csv):
    rows = []

    with open(report_path, encoding="utf-8", errors="ignore") as f:
        for line in f:
            m = ERROR_RE.search(line)
            if m:
                rows.append({
                    "Severity": m.group(1).upper(),
                    "Page": m.group(2),
                    "Message": m.group(3).strip()
                })

    with open(output_csv, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(
            csvfile,
            fieldnames=["Severity", "Page", "Message"]
        )
        writer.writeheader()
        writer.writerows(rows)

    print("Nova error report parsed:", output_csv)


# ----------------------------
# RUN
# ----------------------------
if __name__ == "__main__":
    parse_nova_report(
        "NovaValidationReport.txt",
        "NovaErrors.csv"
    )
