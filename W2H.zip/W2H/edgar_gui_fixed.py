import tkinter as tk
from tkinter import filedialog, messagebox
import subprocess
import sys
import os

def run_pipeline():
    # -----------------------------
    # Select folders
    # -----------------------------
    word_dir = filedialog.askdirectory(title="Select Word Input Folder")
    if not word_dir:
        return

    output_dir = filedialog.askdirectory(title="Select Output Folder (HTML + Images)")
    if not output_dir:
        return

    use_xbrl = xbrl_var.get()

    try:
        # -----------------------------
        # Word → EDGAR HTML
        # -----------------------------
        subprocess.run(
            ["python", "word_to_edgar_enterprise.py", word_dir, output_dir],
            check=True
        )

        # -----------------------------
        # Nova auto-fix (HTML cleanup)
        # -----------------------------
        subprocess.run(
            ["python", "autofix_html.py", output_dir],
            check=True
        )

        # -----------------------------
        # SEC Simulation
        # -----------------------------
        if use_xbrl:
            subprocess.run(
                ["python", "sec_xbrl_simulator.py", output_dir],
                check=True
            )
        else:
            subprocess.run(
                ["python", "sec_html_only_simulator.py", output_dir],
                check=True
            )

        messagebox.showinfo(
            "SUCCESS",
            "EDGAR validation PASSED.\nFiles are safe for submission."
        )

    except subprocess.CalledProcessError:
        messagebox.showerror(
            "FAILED",
            "Validation FAILED.\nPlease review console output."
        )

# -----------------------------
# GUI SETUP
# -----------------------------

root = tk.Tk()
root.title("EDGAR Filing Automation")
root.geometry("560x280")

xbrl_var = tk.BooleanVar(value=False)

tk.Label(
    root,
    text="EDGAR Filing Automation Tool",
    font=("Arial", 16, "bold")
).pack(pady=15)

tk.Checkbutton(
    root,
    text="XBRL Filing (10-K / 10-Q / S-1)",
    variable=xbrl_var,
    font=("Arial", 12)
).pack(pady=10)

tk.Button(
    root,
    text="RUN EDGAR VALIDATION",
    font=("Arial", 13),
    width=32,
    command=run_pipeline
).pack(pady=30)

root.mainloop()
