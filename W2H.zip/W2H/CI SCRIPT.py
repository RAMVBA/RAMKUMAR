import sys
import subprocess
import os

def fail(msg):
    print("❌ FAIL:", msg)
    sys.exit(1)

def run(cmd):
    print("▶", " ".join(cmd))
    subprocess.run(cmd, check=True)

# ---------------------------------
# CONFIG
# ---------------------------------
WORD_DIR = "Word_Input"
OUT_DIR = "Output"
PDF_DIR = "PDF"
NOVA_REPORT = "NovaValidationReport.txt"

# ---------------------------------
# RUN PIPELINE
# ---------------------------------
run(["python", "word_to_edgar_enterprise.py", WORD_DIR, OUT_DIR])

if os.path.exists(NOVA_REPORT):
    run(["python", "parse_nova_report.py"])
else:
    fail("Nova validation report missing")

run(["python", "pdf_html_reconcile.py"])

print("✅ CI PIPELINE PASSED")
